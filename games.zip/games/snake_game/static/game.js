/**
 * ================================================================
 * SNAKE GAME — game.js  (v2 — 600×600 canvas, 30×30 grid)
 * ================================================================
 */

"use strict";

/* ----------------------------------------------------------------
   1. CONSTANTS
   ---------------------------------------------------------------- */

/** Grid cells per axis (canvas = 600px ÷ 20px = 30 cells) */
const GRID_SIZE = 30;

/** Pixel size of each grid cell */
const CELL_SIZE = 600 / GRID_SIZE; // 20px

/** Base tick speeds (ms/tick) — lower = faster */
const SPEEDS = {
    easy: 140,
    medium: 100,
    hard: 65,
};

const POINTS_PER_FOOD = 10;

/** Score milestones for level-up */
const LEVEL_THRESHOLDS = [0, 50, 150, 300, 500, 800, 1200];

/** Speed reduction per level (ms) */
const SPEED_PER_LEVEL = 5;

/** localStorage key for high score */
const HS_KEY = "snakeHighScore";

/* ----------------------------------------------------------------
   2. DOM REFERENCES
   ---------------------------------------------------------------- */
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scoreDisplay = document.getElementById("scoreDisplay");
const highScoreDisplay = document.getElementById("highScoreDisplay");
const levelDisplay = document.getElementById("levelDisplay");
const overlay = document.getElementById("canvasOverlay");
const overlayContent = document.getElementById("overlayContent");
const diffButtons = document.querySelectorAll(".diff-btn");

/* ----------------------------------------------------------------
   3. GAME STATE
   ---------------------------------------------------------------- */
let snake = [];
let direction = {};
let nextDirection = {};
let food = {};
let score = 0;
let highScore = 0;
let level = 1;
let gameLoopId = null;
let isPaused = false;
let isRunning = false;
let difficulty = "medium";
let particles = [];

/* ----------------------------------------------------------------
   4. AUDIO  (Web Audio API — no external files)
   ---------------------------------------------------------------- */
let audioCtx = null;

function initAudio() {
    if (!audioCtx) {
        try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
        catch (_) { audioCtx = null; }
    }
}

function playTone(frequency, duration = 0.08, type = "sine", gain = 0.15) {
    if (!audioCtx) return;
    try {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);
        gainNode.gain.setValueAtTime(gain, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    } catch (_) { }
}

const SFX = {
    eat: () => { playTone(660, 0.08, "sine", 0.15); playTone(880, 0.06, "sine", 0.08); },
    die: () => { playTone(220, 0.35, "sawtooth", 0.2); playTone(110, 0.5, "sawtooth", 0.18); },
    levelUp: () => {
        [523, 659, 784, 1047].forEach((f, i) =>
            setTimeout(() => playTone(f, 0.12, "sine", 0.12), i * 80)
        );
    },
};

/* ----------------------------------------------------------------
   5. HIGH SCORE
   ---------------------------------------------------------------- */
function loadHighScore() {
    const saved = localStorage.getItem(HS_KEY);
    highScore = saved ? parseInt(saved, 10) : 0;
    highScoreDisplay.textContent = highScore;
}

function saveHighScore() {
    if (score > highScore) {
        highScore = score;
        localStorage.setItem(HS_KEY, highScore);
        highScoreDisplay.textContent = highScore;
        return true;
    }
    return false;
}

/* ----------------------------------------------------------------
   6. UTILITIES
   ---------------------------------------------------------------- */
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function spawnFood() {
    let pos;
    do {
        pos = { x: randomInt(0, GRID_SIZE), y: randomInt(0, GRID_SIZE) };
    } while (snake.some(s => s.x === pos.x && s.y === pos.y));
    food = pos;
}

function tickInterval() {
    return Math.max(SPEEDS[difficulty] - (level - 1) * SPEED_PER_LEVEL, 40);
}

function computeLevel() {
    for (let i = LEVEL_THRESHOLDS.length - 1; i >= 0; i--) {
        if (score >= LEVEL_THRESHOLDS[i]) return i + 1;
    }
    return 1;
}

/* ----------------------------------------------------------------
   7. PARTICLES
   ---------------------------------------------------------------- */
function spawnParticles(gx, gy, color = "#3dff7a") {
    const cx = gx * CELL_SIZE + CELL_SIZE / 2;
    const cy = gy * CELL_SIZE + CELL_SIZE / 2;
    for (let i = 0; i < 12; i++) {
        const angle = (Math.PI * 2 * i) / 12;
        const speed = randomInt(2, 6);
        particles.push({
            x: cx, y: cy,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            alpha: 1, color,
            radius: randomInt(2, 5),
        });
    }
}

function updateParticles() {
    particles = particles.filter(p => p.alpha > 0.04);
    for (const p of particles) {
        p.x += p.vx; p.y += p.vy;
        p.vx *= 0.88; p.vy *= 0.88;
        p.alpha -= 0.035;
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.globalAlpha = 1;
}

/* ----------------------------------------------------------------
   8. INIT / RESET
   ---------------------------------------------------------------- */
function initGame() {
    score = 0;
    level = 1;
    particles = [];
    direction = { x: 1, y: 0 };
    nextDirection = { x: 1, y: 0 };

    const midX = Math.floor(GRID_SIZE / 2);
    const midY = Math.floor(GRID_SIZE / 2);
    snake = [
        { x: midX, y: midY },
        { x: midX - 1, y: midY },
        { x: midX - 2, y: midY },
    ];

    spawnFood();
    updateHUD();
}

/* ----------------------------------------------------------------
   9. HUD
   ---------------------------------------------------------------- */
function updateHUD() {
    scoreDisplay.textContent = score;
    levelDisplay.textContent = level;

    scoreDisplay.classList.remove("pop");
    void scoreDisplay.offsetWidth;
    scoreDisplay.classList.add("pop");
    setTimeout(() => scoreDisplay.classList.remove("pop"), 250);
}

/* ----------------------------------------------------------------
   10. DRAW
   ---------------------------------------------------------------- */
function draw() {
    clearCanvas();
    drawGrid();
    drawFood();
    drawSnake();
    updateParticles();
}

function clearCanvas() {
    ctx.fillStyle = "#090912";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawGrid() {
    ctx.strokeStyle = "rgba(255,255,255,0.03)";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= GRID_SIZE; i++) {
        const p = i * CELL_SIZE;
        ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, canvas.height); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(canvas.width, p); ctx.stroke();
    }
}

function drawFood() {
    const cx = food.x * CELL_SIZE + CELL_SIZE / 2;
    const cy = food.y * CELL_SIZE + CELL_SIZE / 2;
    const r = CELL_SIZE / 2 - 2;
    const pulse = 1 + 0.14 * Math.sin(Date.now() / 280);

    // Glow
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 1.8 * pulse);
    grad.addColorStop(0, "rgba(255, 80, 80, 0.7)");
    grad.addColorStop(1, "rgba(255, 80, 80, 0)");
    ctx.beginPath();
    ctx.arc(cx, cy, r * 1.8 * pulse, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Body
    ctx.beginPath();
    ctx.arc(cx, cy, r * pulse, 0, Math.PI * 2);
    ctx.fillStyle = "#ff5f5f";
    ctx.fill();

    // Shine
    ctx.beginPath();
    ctx.arc(cx - r * 0.28, cy - r * 0.28, r * 0.24, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.fill();
}

function drawSnake() {
    for (let i = 0; i < snake.length; i++) {
        const seg = snake[i];
        const x = seg.x * CELL_SIZE;
        const y = seg.y * CELL_SIZE;
        const size = CELL_SIZE - 2;
        const pad = 1;

        if (i === 0) {
            // Head with glow
            ctx.shadowColor = "#3dff7a";
            ctx.shadowBlur = 20;
            drawRoundRect(x + pad, y + pad, size, size, 7, "#3dff7a");
            ctx.shadowBlur = 0;
            drawEyes(seg, size, pad, x, y);
        } else {
            const ratio = i / Math.max(snake.length - 1, 1);
            const r = Math.round(61 - ratio * 30);
            const g = Math.round(255 - ratio * 100);
            const b = Math.round(122 - ratio * 60);
            drawRoundRect(x + pad, y + pad, size, size, i < snake.length - 1 ? 5 : 3, `rgb(${r},${g},${b})`);
        }
    }
}

function drawEyes(seg, size, pad, x, y) {
    const cx = x + pad + size / 2;
    const cy = y + pad + size / 2;
    const offset = size * 0.22;
    const eyeR = size * 0.13;
    const pupilR = eyeR * 0.55;
    const perpX = -direction.y;
    const perpY = direction.x;

    const eye1X = cx + direction.x * offset * 0.5 + perpX * offset;
    const eye1Y = cy + direction.y * offset * 0.5 + perpY * offset;
    const eye2X = cx + direction.x * offset * 0.5 - perpX * offset;
    const eye2Y = cy + direction.y * offset * 0.5 - perpY * offset;

    ctx.fillStyle = "white";
    ctx.beginPath(); ctx.arc(eye1X, eye1Y, eyeR, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(eye2X, eye2Y, eyeR, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = "#080810";
    ctx.beginPath(); ctx.arc(eye1X + direction.x * 1.5, eye1Y + direction.y * 1.5, pupilR, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(eye2X + direction.x * 1.5, eye2Y + direction.y * 1.5, pupilR, 0, Math.PI * 2); ctx.fill();
}

function drawRoundRect(x, y, w, h, r, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
}

/* ----------------------------------------------------------------
   11. GAME LOOP
   ---------------------------------------------------------------- */
function gameTick() {
    if (isPaused || !isRunning) return;

    direction = { ...nextDirection };

    const head = snake[0];
    const newHead = { x: head.x + direction.x, y: head.y + direction.y };

    // Wall collision
    if (newHead.x < 0 || newHead.x >= GRID_SIZE ||
        newHead.y < 0 || newHead.y >= GRID_SIZE) {
        endGame(); return;
    }

    // Self collision
    for (let i = 0; i < snake.length - 1; i++) {
        if (snake[i].x === newHead.x && snake[i].y === newHead.y) {
            endGame(); return;
        }
    }

    snake.unshift(newHead);

    // Food
    if (newHead.x === food.x && newHead.y === food.y) {
        score += POINTS_PER_FOOD;
        SFX.eat();
        spawnParticles(food.x, food.y, "#ff5f5f");
        spawnFood();

        const newLevel = computeLevel();
        if (newLevel > level) {
            level = newLevel;
            SFX.levelUp();
            restartLoop();
        }
        updateHUD();
    } else {
        snake.pop();
    }

    draw();
}

function startLoop() { if (gameLoopId) clearInterval(gameLoopId); gameLoopId = setInterval(gameTick, tickInterval()); }
function restartLoop() { startLoop(); }

/* ----------------------------------------------------------------
   12. LIFECYCLE
   ---------------------------------------------------------------- */
function startGame() {
    initAudio();
    initGame();
    hideOverlay();
    isRunning = true;
    isPaused = false;
    startLoop();
    draw();
}

function togglePause() {
    if (!isRunning) return;
    isPaused = !isPaused;
    isPaused ? showOverlay(buildPauseHTML()) : hideOverlay();
}

function endGame() {
    isRunning = false;
    clearInterval(gameLoopId);
    gameLoopId = null;
    SFX.die();
    drawDeadSnake();
    const isNewBest = saveHighScore();
    setTimeout(() => showOverlay(buildGameOverHTML(isNewBest)), 400);
}

function drawDeadSnake() {
    for (let i = 0; i < snake.length; i++) {
        const seg = snake[i];
        drawRoundRect(seg.x * CELL_SIZE + 1, seg.y * CELL_SIZE + 1, CELL_SIZE - 2, CELL_SIZE - 2, i === 0 ? 7 : 4, "#ff5f5f");
    }
}

/* ----------------------------------------------------------------
   13. OVERLAY
   ---------------------------------------------------------------- */
function showOverlay(html) {
    overlayContent.innerHTML = html;
    overlay.classList.remove("hidden");
    document.getElementById("startBtn")?.addEventListener("click", startGame);
    document.getElementById("restartBtn")?.addEventListener("click", startGame);
    document.getElementById("resumeBtn")?.addEventListener("click", togglePause);
}
function hideOverlay() { overlay.classList.add("hidden"); }

function buildStartHTML() {
    return `
        <div class="overlay-emoji">🐍</div>
        <div class="overlay-title">SNAKE</div>
        <div class="overlay-score-info">
            Use arrow keys to move<br/>
            Eat food to grow &amp; score<br/>
            Avoid walls and yourself!
        </div>
        <button class="overlay-btn primary" id="startBtn">▶ &nbsp;START GAME</button>
    `;
}

function buildGameOverHTML(isNewBest) {
    return `
        <div class="overlay-emoji">💀</div>
        <div class="overlay-title danger">GAME OVER</div>
        <div class="overlay-score-info">
            Score &nbsp;<span>${score}</span><br/>
            Level &nbsp;<span>${level}</span><br/>
            Best &nbsp;&nbsp;<span>${highScore}</span>
            ${isNewBest ? '<br/><span class="new-best">🏆 NEW HIGH SCORE!</span>' : ""}
        </div>
        <button class="overlay-btn primary"   id="restartBtn">🔄 &nbsp;PLAY AGAIN</button>
    `;
}

function buildPauseHTML() {
    return `
        <div class="overlay-emoji">⏸</div>
        <div class="overlay-title">PAUSED</div>
        <div class="overlay-score-info">Score &nbsp;<span>${score}</span> &nbsp;|&nbsp; Level &nbsp;<span>${level}</span></div>
        <button class="overlay-btn primary"   id="resumeBtn">▶ &nbsp;RESUME</button>
        <button class="overlay-btn secondary" id="restartBtn">🔄 &nbsp;RESTART</button>
    `;
}

/* ----------------------------------------------------------------
   14. INPUT
   ---------------------------------------------------------------- */
const KEY_MAP = {
    ArrowUp: { x: 0, y: -1 }, w: { x: 0, y: -1 },
    ArrowDown: { x: 0, y: 1 }, s: { x: 0, y: 1 },
    ArrowLeft: { x: -1, y: 0 }, a: { x: -1, y: 0 },
    ArrowRight: { x: 1, y: 0 }, d: { x: 1, y: 0 },
};

document.addEventListener("keydown", (e) => {
    initAudio();
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) e.preventDefault();
    if (e.key === "p" || e.key === "P") { togglePause(); return; }
    if ((e.key === "r" || e.key === "R") && !isPaused) { startGame(); return; }

    const newDir = KEY_MAP[e.key];
    if (!newDir || !isRunning || isPaused) return;
    if (newDir.x === -direction.x && newDir.y === -direction.y) return;
    nextDirection = newDir;
});

/* ----------------------------------------------------------------
   15. DIFFICULTY BUTTONS
   ---------------------------------------------------------------- */
diffButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        initAudio();
        difficulty = btn.dataset.difficulty;
        diffButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        if (isRunning && !isPaused) startLoop();
    });
});

/* ----------------------------------------------------------------
   16. BOOT
   ---------------------------------------------------------------- */
(function boot() {
    loadHighScore();
    showOverlay(buildStartHTML());
    clearCanvas();
    drawGrid();
})();
