"""
Snake Game - Flask Backend
==========================
A minimal Flask server that serves the Snake Game frontend.
No database is required - all game state lives in the browser.

Usage:
    pip install flask
    python app.py

Visit http://127.0.0.1:5000/ in your browser to play.
"""

from flask import Flask, render_template

# Initialize the Flask application
app = Flask(__name__)


@app.route("/")
def index():
    """
    Root route: Renders the main game page (index.html).
    All game logic is handled client-side via JavaScript.
    """
    return render_template("index.html")


if __name__ == "__main__":
    # Run in debug mode for development.
    # Set debug=False before deploying to production.
    app.run(debug=True)
